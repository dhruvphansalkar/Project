package com.project.client1.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

//Collection name in mongodb for this entity class is LoanProgramsOffered in LoanManagement database
@Document(collection="LoanProgramsOffered")
public class LoanProgramsOffered
{
		//Unique identifier for each entry in the collection 
		@Id
		private String programName;
		private String description; 
		private String type;
		private int durationInYears;
		private double minLoanAmount;
		private double maxLoanAmount;
		private double rateOfInterest;
		String proofsRequired;
		
		//getters and setters for all variables
		public String getProgramName() {
			return programName;
		}
		public void setProgramName(String programName) {
			programName = this.programName;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public int getDurationInYears() {
			return durationInYears;
		}
		public void setDurationInYears(int durationInYears) {
			this.durationInYears = durationInYears;
		}
		public double getMinLoanAmount() {
			return minLoanAmount;
		}
		public void setMinLoanAmount(double minLoanAmount) {
			this.minLoanAmount = minLoanAmount;
		}
		public double getMaxLoanAmount() {
			return maxLoanAmount;
		}
		public void setMaxLoanAmount(double maxLoanAmount) {
			this.maxLoanAmount = maxLoanAmount;
		}
		public double getRateOfInterest() {
			return rateOfInterest;
		}
		public void setRateOfInterest(double rateOfInterest) {
			this.rateOfInterest = rateOfInterest;
		}
		public String getProofsRequired() {
			return proofsRequired;
		}
		public void setProofsRequired(String proofsRequired) {
			this.proofsRequired = proofsRequired;
		}
}
