package com.project.client1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.netflix.discovery.shared.Application;
import com.project.client1.entity.LoanApplication;
import com.project.client1.entity.LoanProgramsOffered;
import com.project.client1.entity.ResponseClient;
import com.project.client1.entity.UserLogin;
import com.project.client1.exception.ApplicationNotFoundException;

@RestController
public class Controller 
{
	@Autowired
    private RestTemplate restTemplate;
    @Autowired
    private EurekaClient eurekaClient;
    
    @GetMapping("/dashboard/1/{id}")
    public LoanApplication getDetails(@PathVariable String id)
    {
    	Application app = eurekaClient.getApplication("View-Application-On-Basis-Of-Id");
    	InstanceInfo inst = app.getInstances().get(0);
    	String url = "http://" + inst.getIPAddr() + ":" + inst.getPort() + "/" + "/ViewOnBasisOfId/" + id;
    	System.out.println("URL" + url);
    	LoanApplication la = restTemplate.getForObject(url, LoanApplication.class);
    	if(la == null)
    	{
    		throw new ApplicationNotFoundException("No Application exists with id = "+id);
    	}
    	return la;
    }
    @RequestMapping("/actuator/info")
    public String apiinfo()
    {
    	return "Welcome to Loan Management System";
    }
    @PostMapping(value="/dashboard/2", consumes=MediaType.APPLICATION_JSON_VALUE)
    public String insertLoan(@RequestBody LoanProgramsOffered lpo)
    {
        Application app=eurekaClient.getApplication("Add-Loan");
        InstanceInfo instanceInfo=app.getInstances().get(0);
        String url="http://"+instanceInfo.getIPAddr()+":"+instanceInfo.getPort()+"/addLoan";
        /*ResponseClient bd= restTemplate.postForObject(url,lpo,ResponseClient.class);
        String res = bd.getResponse();
        return res; */
        return restTemplate.postForObject(url,lpo,String.class);
    }
    @PostMapping(value="/dashboard/3", consumes=MediaType.APPLICATION_JSON_VALUE)
    public String insertApplicationDetails(@RequestBody LoanApplication la)
    {
        Application app=eurekaClient.getApplication("Apply-for-loan");
        InstanceInfo instanceInfo=app.getInstances().get(0);
        String url="http://"+instanceInfo.getIPAddr()+":"+instanceInfo.getPort()+"/applyForLoan";
        /*ResponseClient bd= restTemplate.postForObject(url,la,ResponseClient.class);
        String res = bd.getResponse();
        return res; */
        return restTemplate.postForObject(url,la,String.class);
    }
    @PostMapping(value="/dashboard/4", consumes=MediaType.APPLICATION_JSON_VALUE)
    public String loginCheck(@RequestBody UserLogin ul)
    {
        Application app=eurekaClient.getApplication("Login-User");
        InstanceInfo instanceInfo=app.getInstances().get(0);
        String url="http://"+instanceInfo.getIPAddr()+":"+instanceInfo.getPort()+"/validateUser";
        /*ResponseClient bd= restTemplate.postForObject(url,la,ResponseClient.class);
        String res = bd.getResponse();
        return res; */
        return restTemplate.postForObject(url,ul,String.class);
    }
}


