package com.project.UpdateStatusOnBasisOfId.service;
import org.springframework.data.mongodb.repository.MongoRepository;
import com.project.UpdateStatusOnBasisOfId.entity.LoanApplication;
public interface UpdateStatusOnBasisOfIdInterface extends MongoRepository<LoanApplication, Integer>{

}