package com.project.UpdateStatusOnBasisOfId;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication
@ComponentScan(basePackages="com.project.UpdateStatusOnBasisOfId")
@EnableMongoRepositories(basePackages="com.project.UpdateStatusOnBasisOfId")
@EnableEurekaClient
public class UpdateStatusOnBasisOfIdApplication {

	public static void main(String[] args) {
		SpringApplication.run(UpdateStatusOnBasisOfIdApplication.class, args);
	}
}


/*{
"applicationId" : 1,
"applicationDate": "2018-10-16",
"loanProgram" : "Program_A",
"amountOfLoan":10000,
"addressOfProperty":"Mumbai",
"annualFamilyIncome":10000,
"documentProofsAvailable":"Aadhar",
"guaranteeCover":"House",
"marketValueofGuaranteeCover":5000,
"status":"Confirm",
"dateOfInterview":"2018-10-20"
}*/