package com.project.UpdateStatusOnBasisOfId.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.UpdateStatusOnBasisOfId.service.UpdateStatusOnBasisOfIdInterface;
import com.project.UpdateStatusOnBasisOfId.entity.*;

@RestController
public class UpdateStatusOnBasisOfIdController {
	@Autowired
	UpdateStatusOnBasisOfIdInterface upi;
	@PostMapping(value="/UpdateStatus")
	public String UpdateStatus(@RequestBody LoanApplication Up){
		upi.save(Up);
		return "success";
	}
}