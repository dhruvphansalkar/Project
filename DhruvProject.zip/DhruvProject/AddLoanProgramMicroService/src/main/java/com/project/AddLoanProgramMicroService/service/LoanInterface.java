package com.project.AddLoanProgramMicroService.service;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.project.AddLoanProgramMicroService.entity.LoanProgramsOffered;

public interface LoanInterface extends MongoRepository<LoanProgramsOffered, String> 
{

}
