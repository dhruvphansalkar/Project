package com.project.AddLoanProgramMicroService.controller;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.project.AddLoanProgramMicroService.entity.LoanProgramsOffered;
import com.project.AddLoanProgramMicroService.service.LoanInterface;


@RestController
public class AddLoanProgMicroService
{

	@Autowired
	LoanInterface loanOperation=null;
	
	Logger daoLogger=null;
	
	public AddLoanProgMicroService()
	{
		daoLogger=Logger.getLogger(AddLoanProgMicroService.class);
		PropertyConfigurator.configure("log4j.properties");
	}
	
	@PostMapping(value="/addLoan")
	public String addLoan(@RequestBody LoanProgramsOffered loan)
	{
		//Insertion in the LoanProgramsOffered table
			loanOperation.save(loan);
			daoLogger.info("Data inserted:"+loan);
			return "success";
	}
	
}
