package com.project.ApplyforLoanMicroService.service;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.project.ApplyforLoanMicroService.entity.LoanApplication;

public interface LoanApplicationInterface extends MongoRepository<LoanApplication, Integer>
{

}
