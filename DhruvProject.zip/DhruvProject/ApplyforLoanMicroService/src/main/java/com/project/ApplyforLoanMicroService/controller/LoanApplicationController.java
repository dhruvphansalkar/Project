package com.project.ApplyforLoanMicroService.controller;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.project.ApplyforLoanMicroService.entity.LoanApplication;
import com.project.ApplyforLoanMicroService.service.LoanApplicationInterface;


@RestController
public class LoanApplicationController
{
	@Autowired
	LoanApplicationInterface lpi;
	
	Logger daoLogger=null;
	
	public LoanApplicationController()
	{
		daoLogger=Logger.getLogger(LoanApplicationController.class);
		PropertyConfigurator.configure("log4j.properties");
	}
	
	@PostMapping(value="/applyForLoan")
	public String AddUser(@RequestBody LoanApplication lp)
	{
		lpi.save(lp);
		daoLogger.info("Data Inserted:"+lp);
		return "success";
	}
	
	
}
