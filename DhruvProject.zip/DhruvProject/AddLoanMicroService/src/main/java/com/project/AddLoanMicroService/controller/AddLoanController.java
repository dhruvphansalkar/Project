package com.project.AddLoanMicroService.controller;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.AddLoanMicroService.entity.UserLogin;
import com.project.AddLoanMicroService.service.UserInterface;

@RestController
public class AddLoanController 
{
	@Autowired
	UserInterface ui;
	UserLogin data = null;
	Logger daoLogger=null;
	
	public AddLoanController()
	{
		daoLogger=Logger.getLogger(AddLoanController.class);
		PropertyConfigurator.configure("log4j.properties");
	}
	@PostMapping(value="/addUser")
	public String AddUser(@RequestBody UserLogin ul)
	{
		ui.save(ul);
		daoLogger.info("User added successfully");
		return "success";
		
	}
	
	@PostMapping(value="/validateUser")
	public String validateUser(@RequestBody UserLogin ul)
	{
		data = ui.findByIdAndPassword(ul.getId(), ul.getPassword());
		if(data != null)
		{
			daoLogger.info("Successful Login");
			return "Welcome user";
			
		}
		else
		{
			daoLogger.info("Invalid Credentials");
			return "Incorrect id and Password";
		}
		
	}

}
