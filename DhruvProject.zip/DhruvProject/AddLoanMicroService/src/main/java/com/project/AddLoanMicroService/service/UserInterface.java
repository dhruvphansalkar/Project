package com.project.AddLoanMicroService.service;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.project.AddLoanMicroService.entity.UserLogin;

public interface UserInterface extends MongoRepository<UserLogin, String> 
{
	public UserLogin findByIdAndPassword(String id, String password);
}
