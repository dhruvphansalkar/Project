package com.project.ViewApplicationOnBasisOfId.service;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.project.ViewApplicationOnBasisOfId.entity.LoanApplication;


public interface ViewApplicationOnBasisOfIdInterface extends MongoRepository<LoanApplication, Integer> {

	

}
