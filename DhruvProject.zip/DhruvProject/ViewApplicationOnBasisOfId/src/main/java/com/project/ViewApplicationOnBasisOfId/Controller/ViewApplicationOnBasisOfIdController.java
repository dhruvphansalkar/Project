package com.project.ViewApplicationOnBasisOfId.Controller;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.project.ViewApplicationOnBasisOfId.entity.LoanApplication;
import com.project.ViewApplicationOnBasisOfId.service.ViewApplicationOnBasisOfIdInterface;

@RestController
public class ViewApplicationOnBasisOfIdController {

	@Autowired
	ViewApplicationOnBasisOfIdInterface vs;
	
	Logger daoLogger=null;
	
	public ViewApplicationOnBasisOfIdController()
	{
		daoLogger=Logger.getLogger(ViewApplicationOnBasisOfIdController.class);
		PropertyConfigurator.configure("log4j.properties");
	}
	
	@GetMapping(value="/ViewOnBasisOfId/{id}")
	public LoanApplication getById(@PathVariable("id")int id)
	{
		daoLogger.info("Data Retrieved");
		if(!vs.existsById(id))
		{
			return null;
		}
		else
		{
			return  vs.findById(id).get();
		}

	}
}

	

